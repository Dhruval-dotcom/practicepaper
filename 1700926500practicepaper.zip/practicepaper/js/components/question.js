const Question = (prop, data) => {
    `<h2 id="Question-${prop}"> Question - ${prop} </h2><hr>
    ${data[prop]['question_descreption']} <br><br>
    <input type="checkbox" name="" id="option-${prop}-a"><label for="option-${prop}-a">${data[prop]['option-1']} </label> <br>
    <input type="checkbox" name="" id="option-${prop}-b"><label for="option-${prop}-b">${data[prop]['option-2']} </label> <br>
    <input type="checkbox" name="" id="option-${prop}-c"><label for="option-${prop}-c">${data[prop]['option-3']} </label> <br>
    <input type="checkbox" name="" id="option-${prop}-d"><label for="option-${prop}-d">${data[prop]['option-4']} </label> <br>
    <button>Check answer</button>`
}
export { Question };