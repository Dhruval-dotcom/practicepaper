$('body').append('<ul></ul>');

$.ajax({
    url: "http://localhost/practicepaper/handler/loadlist.php",
    type: "get",
    data: {
        id: 1,
    },
    dataType: "JSON",
    success: function (data) {
        for(const prop in data){
            const link = data[prop].replaceAll(' ', '_')
            $('ul').append(`<li><a href='question.html?topic=${link}&pageno=1'>${data[prop]}</a></li>`);
        }
        console.log(data);
    },
    error: function(jqXHR, textStatus, errorThrown) {
        console.log(textStatus, errorThrown);
    }
});