$('body').append('<ul></ul>');

const listComponent = (link, prop) => {
    return(`
    <div class="alert alert-primary text-center me-4" role="alert">
        <a href='question.html?topic=${link}&pageno=1'>${prop}</a>
    </div>
    `);
}
$.ajax({
    url: "http://localhost/practicepaper/handler/loadlist.php",
    type: "get",
    data: {},
    dataType: "JSON",
    success: function (data) {
        for(const prop in data){
            const link = data[prop].replaceAll(' ', '_')
            $('ul').append(listComponent(link, data[prop]));
        }
        console.log(data);
    },
    error: function(jqXHR, textStatus, errorThrown) {
        console.log(textStatus, errorThrown);
    }
});