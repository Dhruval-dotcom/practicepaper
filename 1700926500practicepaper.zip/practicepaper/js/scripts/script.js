var script = document.createElement('script');
script.src = 'http://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/MathJax.js?config=TeX-AMS-MML_HTMLorMML'; 
script.type = 'text/javascript'    // Check https://jquery.com/ for the current version
document.getElementsByTagName('head')[0].appendChild(script);
