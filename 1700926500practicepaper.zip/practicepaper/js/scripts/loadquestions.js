//loading pagenumber and topic from link
const url = new URL(window.location.href);
const pageno = +url.searchParams.get('pageno');
const topic = url.searchParams.get('topic');

//each question component
const Question = (prop, data, number) => {
    return (`<h2 id="Question-${(pageno-1)*3+number}"> Question - ${(pageno-1)*3+number} </h2>
    GATE CSE ${data[prop]['year']} (<i>${data[prop]['chapter']}</i>) <hr>
    ${data[prop]['question_descreption']} <br><br>
    <input type="checkbox" name="" id="option-${prop}-a"><label for="option-${prop}-a">${data[prop]['option-1']} </label> <br>
    <input type="checkbox" name="" id="option-${prop}-b"><label for="option-${prop}-b">${data[prop]['option-2']} </label> <br>
    <input type="checkbox" name="" id="option-${prop}-c"><label for="option-${prop}-c">${data[prop]['option-3']} </label> <br>
    <input type="checkbox" name="" id="option-${prop}-d"><label for="option-${prop}-d">${data[prop]['option-4']} </label> <br>
    <button class="check">Check answer</button>`);
}

const totalItems = 10;
const pagination = (totalItems) => {
    let links = ''
    for(let i = 1; i <= Math.ceil(totalItems/3); i++){
        links = links + `<li class="page-item ${pageno == i ? 'active' : ''}">
            <a class="page-link" href="question.html?topic=${topic}&pageno=${i}">${i}</a>
        </li>`;
    }
    return (`
        <nav aria-label="Page navigation example">
            <ul class="pagination justify-content-center">
                <li class="page-item ${pageno == 1 ? 'disabled' : ''}">
                    <a class="page-link" href="question.html?topic=${topic}&pageno=${pageno-1}">Previous</a>
                </li>
                ${links}
                <li class="page-item ${pageno == Math.ceil(totalItems/3) ? 'disabled' : ''}">
                    <a class="page-link" href="question.html?topic=${topic}&pageno=${pageno+1}">Next</a>
                </li>
            </ul>
        </nav>
    `);
}

$.ajax({
    url: "http://localhost/practicepaper/handler/loadquestions.php",
    type: "get",
    data: {
        pageno: pageno,
        topic: topic.replaceAll('_', ' ')
    },
    dataType: "JSON",
    success: function (data) {
        let number = 1;
        for(const prop in data){
            $(`body`).append(Question(prop, data ,number++));
        }
        $(`body`).append(pagination(totalItems));
        console.log(data);
    },
    error: function(jqXHR, textStatus, errorThrown) {
        console.log(textStatus, errorThrown);
    }
});
