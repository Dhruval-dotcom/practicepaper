//loading pagenumber and topic from link
const url = new URL(window.location.href);
const pageno = +url.searchParams.get('pageno');
const topic = url.searchParams.get('topic');



const descriptionComponent = (prop, data) => {
    return (`
    <div id="description-${prop}" class="alert description" role="alert">
        <h4 class="alert-heading">Well done!</h4><hr>
        <p>${data[prop]['answer_description']}</p>
    </div>
    `);
} 


//option component
const OptionComponent = (prop, data, option) => {
    return (`
        <div class="optiondiv" id="optiondiv-${prop}-${option}">
            <input type="checkbox" name="" id="option-${prop}-${option}">
                <label for="option-${prop}-${option}">${data} 
            </label>
        </div>
        <br>
    `);
}


const AllOptions = (prop, data) => {
    return (`
        ${OptionComponent(prop, data[prop]['option-1'], 'a')}
        ${OptionComponent(prop, data[prop]['option-2'], 'b')}
        ${OptionComponent(prop, data[prop]['option-3'], 'c')}
        ${OptionComponent(prop, data[prop]['option-4'], 'd')}
    `)
}



//each question component
const QuestionComponent = (prop, data, number) => {
    return (`
        <h2 id="Question-${(pageno-1)*3+number}"> Question - ${(pageno-1)*3+number} </h2>
        GATE CSE ${data[prop]['year']} (<i>${data[prop]['chapter']}</i>) 
        <span class="checkanswerspan badge rounded-pill" id="checkanswerspan-${prop}"></span> <hr>
        ${data[prop]['question_description']} <br><br>

        ${data[prop]['type_of_que'] == 'numeric' ?  "<input type='number' id='numeric-type-" + prop + "'><br>" : AllOptions(prop, data)}

        <button id="btn-check-${prop}" onclick="checkAnswer(${prop}, '${data[prop]['solution']}', '${data[prop]['type_of_que']}', '${data[prop]['start_val']}', '${data[prop]['stop_val']}')" class="btn btn-primary check">
            Check answer
        </button>
        <br>
        ${descriptionComponent(prop, data)}
    `);
}



const totalItems = 10;
const pagination = (totalItems) => {
    let links = ''
    for(let i = 1; i <= Math.ceil(totalItems/3); i++){
        links = links + `<li class="page-item ${pageno == i ? 'active' : ''}">
            <a class="page-link" href="question.html?topic=${topic}&pageno=${i}">${i}</a>
        </li>`;
    }
    return (`
        <nav aria-label="Page navigation example">
            <ul class="pagination justify-content-center">
                <li class="page-item ${pageno == 1 ? 'disabled' : ''}">
                    <a class="page-link" href="question.html?topic=${topic}&pageno=${pageno-1}">Previous</a>
                </li>
                ${links}
                <li class="page-item ${pageno == Math.ceil(totalItems/3) ? 'disabled' : ''}">
                    <a class="page-link" href="question.html?topic=${topic}&pageno=${pageno+1}">Next</a>
                </li>
            </ul>
        </nav>
    `);
}



$.ajax({
    url: "http://localhost/practicepaper/handler/loadquestions.php",
    type: "get",
    data: {
        pageno: pageno,
        topic: topic.replaceAll('_', ' ')
    },
    dataType: "JSON",
    success: function (data) {
        let number = 1;
        for(const prop in data){
            $(`body`).append(QuestionComponent(prop, data ,number++));
        }
        $(`body`).append(pagination(totalItems));

        console.log(data);
    },
    error: function(jqXHR, textStatus, errorThrown) {
        console.log(textStatus, errorThrown);
    }
});



const checkcorrectanswer = (solution, selected_ans) => {

    let selectedAnsString = ''; 
    for(let prop in selected_ans){
        if(selected_ans[prop]) 
            selectedAnsString = selectedAnsString + (prop + '|');
    }

    return selectedAnsString == (solution + '|');
}



const actionToCheckAnswer = (id, correctanswer) => {
    if(correctanswer){
        $('#description-' + id).attr('class','description alert alert-primary');
        $('#checkanswerspan-'+id).css('color', '#084298');
        $('#checkanswerspan-'+id).css('background-color', '#cfe2ff');
        $('#checkanswerspan-'+id).css('border-color', '#b6d4fe');
        $('#checkanswerspan-'+id).html('<b><i class="bx bx-check"></i></b> Correct Answer');
        $('#checkanswerspan-'+id).addClass('bg-primary');
    } else {
        $('#description-' + id).attr('class','description alert alert-danger');
        $('#checkanswerspan-'+id).css('color', '#842029');
        $('#checkanswerspan-'+id).css('background-color', '#f8d7da');
        $('#checkanswerspan-'+id).css('border-color', '#f5c2c7');        
        $('#checkanswerspan-'+id).html('<b><i class="bx bx-x"></i></b> Wrong Answer');
        $('#checkanswerspan-'+id).addClass('bg-danger');
    }
}



const checkAnswer = (id, solution, type_of_que, start_val, stop_val) => {
    $(`#btn-check-${id}`).text($(`#btn-check-${id}`).text() == 'Hide answer' ? 'Check answer' : 'Hide answer')

    const selected_ans = {
        a: $(`#option-${id}-a`).prop('checked'),
        b: $(`#option-${id}-b`).prop('checked'),
        c: $(`#option-${id}-c`).prop('checked'),
        d: $(`#option-${id}-d`).prop('checked')
    }

    
    if(type_of_que == 'soc'){
        console.log("Here");
        for(let prop in selected_ans){
            if(selected_ans[prop])
                $('#optiondiv-' + id + '-' + prop).addClass("alert alert-danger");
        }
        $('#optiondiv-' + id + '-' + solution).addClass("alert alert-primary");
        actionToCheckAnswer(id,checkcorrectanswer(solution, selected_ans));
    }


    if(type_of_que == 'mcq'){
        const options = solution.split('|');
        for(let prop in selected_ans){
            if(selected_ans[prop])
                $('#optiondiv-' + id + '-' + prop).addClass("alert alert-danger");
        }
        for(let item in options){
            $('#optiondiv-' + id + '-' + options[item]).addClass("alert alert-primary");
        }
        actionToCheckAnswer(id,checkcorrectanswer(solution, selected_ans));
    }
    
    if(type_of_que == 'numeric'){
        console.log($('#numeric-type-'+id).val());
        const numericanswer = parseFloat($('#numeric-type-'+id).val());
        actionToCheckAnswer(id, numericanswer<=stop_val && numericanswer >= start_val);
    }
    $('#description-' + id).slideToggle();

}
