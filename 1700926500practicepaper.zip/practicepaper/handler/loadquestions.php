<?php
include './conn.php';
$topic = $_GET['topic'];
$sql = "SELECT * FROM question WHERE quiz_id in (SELECT id FROM quiz WHERE name = '". $topic ."') ORDER BY id LIMIT 3 OFFSET ". (3 * ($_GET['pageno'] - 1)) ."";
$result = mysqli_query($conn, $sql);

$arr = [];

if (mysqli_num_rows($result) > 0) {
  // output data of each row
  while($row = mysqli_fetch_assoc($result)) {
    $sql2 = "SELECT * FROM answer where ques_id = ".$row['id'];
    $result2 = mysqli_query($conn, $sql2);
    $row2 = mysqli_fetch_array($result2);
    $arr[$row['id']] = [
        'id' => $row['id'],
        'quiz_id' => $row['quiz_id'],
        'question_description' => $row['question_description'],
        'marks' => $row['marks'],
        'type_of_que' => $row['type_of_que'],
        'solution' => $row['solution'],
        'year' => $row['year'],
        'subject' => $row['subject'],
        'chapter' => $row['chapter'],
        'option-1' => $row['option-1'],
        'option-2' => $row['option-2'],
        'option-3' => $row['option-3'],
        'option-4' => $row['option-4'],
        'answer_description' => $row2['ans_text'],
        'start_val' => $row2['start_val'],
        'stop_val' => $row2['stop_val'],
    ];
  }
} else {
  echo $arr['status'] = 'SELECT id FROM quiz WHERE name = "'. $topic .'"';
}
echo json_encode($arr);
mysqli_close($conn);